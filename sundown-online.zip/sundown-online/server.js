// SUNDOWN 온라인 서버 — Node.js 18 이상, 추가 설치 없음
// 실행: node server.js        (포트 바꾸기: PORT=17813 node server.js)
// 게임 화면: http://<이 컴퓨터 주소>:<포트>/  — 같은 주소로 웹소켓 접속까지 처리합니다.
'use strict';
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const PORT = +process.env.PORT || 17813;
const GOAL = +process.env.GOAL || 25;            // 승리 킬 수
const MATCH_TIME = +process.env.MATCH_TIME || 360; // 경기 시간(초)
const RESPAWN = 3.0, NEXT_MATCH = 12, SPAWN_PROT = 1.2;
const MAX_PLAYERS = 12, MAX_ROOMS = 64, TICK = 50; // 20Hz
const PUBLIC = path.join(__dirname, 'public');

// ---------- map (same grid as the client) ----------
const MAP_ROWS = [
"####################################","########........k...........########","########..c...........kk....########","##....##..c....####...kk....##....##",
"##.........k..........####........##","##..######....####....####..####..##","##..######....####..........####..##","##..######..........####....####..##",
"##....####..kk......####..........##","####..####..k...##........###..#####","####..####......##..c.....###..#####","##....######..####..c...#####....###",
"##..cc######..####.k....#####......#","#......k............######.....c...#","#..........##.......######.........#","#..k.......##..ww.......k.....k....#",
"#..k..c....##.......TT.....###.....#","#.......k.....ww....TT.....###..c..#","#......c....##..............##.....#","#...k######.##.......######........#",
"#....######..........######..cc....#","##...######...####k..######........#","##...######...####.......####..#####","####...........##........####..#####",
"####..####..............####....####","##....####..####..####..........####","##..c.####..####..####..####..k..###","##........k.......####..####..k..###",
"######......####........####......##","######..######..........######....##","###.....######..####..c.######....##","###...............####............##",
"###..cc.....c.....####.....kk.....##","###............k............kk....##","#######..................#######..##","####################################"];
const GW = 36, GH = 36, CELL = 2.4, HW = GW * CELL / 2, HH = GH * CELL / 2;
const WALK = [];
for (let j = 0; j < GH; j++) for (let i = 0; i < GW; i++) if (MAP_ROWS[j][i] === '.') WALK.push([(i + 0.5) * CELL - HW, (j + 0.5) * CELL - HH]);

// ---------- damage tables (must match the client) ----------
const DMG = {
  rifle: { head: 160, body: 40, legs: 34 },
  pistol: { head: 78, body: 26, legs: 22 },
  pistol_alt: { head: 70, body: 24, legs: 20 }
};
const KNIFE = { light: 50, light_back: 100, heavy: 75, heavy_back: 150 };
const WCODE = ['rifle', 'pistol', 'knife'];

// ---------- tiny WebSocket (RFC 6455) ----------
class Conn {
  constructor(sock) {
    this.sock = sock; this.buf = Buffer.alloc(0); this.frag = null; this.closed = false; this.alive = Date.now();
    this.msgBudget = 120; this.player = null; this.room = null;
    sock.setNoDelay(true);
    sock.on('data', d => this.onData(d));
    sock.on('close', () => this.onClose());
    sock.on('error', () => this.onClose());
  }
  onData(d) {
    this.alive = Date.now();
    this.buf = this.buf.length ? Buffer.concat([this.buf, d]) : d;
    if (this.buf.length > 1 << 20) return this.close();
    for (;;) {
      if (this.buf.length < 2) return;
      const b0 = this.buf[0], b1 = this.buf[1], fin = b0 & 0x80, op = b0 & 0x0f;
      let len = b1 & 0x7f, off = 2;
      if (!(b1 & 0x80)) return this.close(); // clients must mask
      if (len === 126) { if (this.buf.length < 4) return; len = this.buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (this.buf.length < 10) return; if (this.buf.readUInt32BE(2)) return this.close(); len = this.buf.readUInt32BE(6); off = 10; }
      if (len > 64 * 1024) return this.close();
      if (this.buf.length < off + 4 + len) return;
      const mask = this.buf.subarray(off, off + 4), payload = Buffer.allocUnsafe(len);
      for (let i = 0; i < len; i++) payload[i] = this.buf[off + 4 + i] ^ mask[i & 3];
      this.buf = this.buf.subarray(off + 4 + len);
      if (op === 8) return this.close();
      if (op === 9) { this.frame(0xA, payload); continue; }
      if (op === 10 || op === 2) continue;
      if (op === 0) { if (!this.frag) return this.close(); this.frag.push(payload); if (fin) { const m = Buffer.concat(this.frag); this.frag = null; this.text(m); } continue; }
      if (op === 1) { if (!fin) { this.frag = [payload]; continue; } this.text(payload); continue; }
      return this.close();
    }
  }
  text(buf) {
    if (--this.msgBudget < 0) return; // flood guard (refilled every second)
    let m; try { m = JSON.parse(buf.toString('utf8')); } catch (e) { return; }
    if (m && typeof m === 'object') onMessage(this, m);
  }
  frame(op, data) {
    if (this.closed || this.sock.destroyed) return;
    if (this.sock.writableLength > 512 * 1024) return this.close(); // too slow, drop
    const len = data.length; let head;
    if (len < 126) head = Buffer.from([0x80 | op, len]);
    else if (len < 65536) { head = Buffer.alloc(4); head[0] = 0x80 | op; head[1] = 126; head.writeUInt16BE(len, 2); }
    else { head = Buffer.alloc(10); head[0] = 0x80 | op; head[1] = 127; head.writeUInt32BE(0, 2); head.writeUInt32BE(len, 6); }
    this.sock.write(Buffer.concat([head, data]));
  }
  send(obj) { this.frame(1, Buffer.from(JSON.stringify(obj))); }
  close() { if (this.closed) return; try { this.sock.end(Buffer.from([0x88, 0])); } catch (e) { } this.sock.destroy(); this.onClose(); }
  onClose() { if (this.closed) return; this.closed = true; leaveRoom(this); }
}

// ---------- rooms ----------
const rooms = new Map();
let nextId = 1;
const now = () => Date.now() / 1000;
const r2 = v => Math.round(v * 100) / 100, r3 = v => Math.round(v * 1000) / 1000;
const num = (v, lo, hi) => (typeof v === 'number' && Number.isFinite(v)) ? Math.min(hi, Math.max(lo, v)) : null;
function cleanName(s) { s = String(s || '').replace(/[\u0000-\u001f\u007f-\u009f​-‏‪-‮⁦-⁩]/g, '').trim().slice(0, 12); return s || '플레이어'; }
function cleanRoom(s) { s = String(s || 'main').toLowerCase().replace(/[^a-z0-9_-]/g, '').slice(0, 16); return s || 'main'; }

function makeRoom(code) {
  const room = { code, players: new Map(), orbs: new Map(), orbSeq: 1, state: 'playing', timeLeft: MATCH_TIME, endedAt: 0 };
  rooms.set(code, room); return room;
}
function broadcast(room, obj, except) { const s = Buffer.from(JSON.stringify(obj)); for (const p of room.players.values()) if (p.conn !== except) p.conn.frame(1, s); }
function pub(p) { return { id: p.id, name: p.name, look: p.look, alive: p.alive, kills: p.kills, deaths: p.deaths, p: [r2(p.x), r2(p.y), r2(p.z)], yaw: r3(p.yaw) }; }

function pickSpawn(room, self) {
  let best = WALK[0], bestS = -1;
  for (let k = 0; k < 40; k++) {
    const c = WALK[Math.floor(Math.random() * WALK.length)];
    let minD = 1e9; for (const o of room.players.values()) if (o !== self && o.alive) minD = Math.min(minD, Math.hypot(o.x - c[0], o.z - c[1]));
    const s = Math.min(minD, 45) + Math.random() * 5;
    if (s > bestS) { bestS = s; best = c; }
  }
  return best;
}
function spawn(room, p) {
  const c = pickSpawn(room, p);
  p.x = c[0]; p.y = 0; p.z = c[1]; p.yaw = Math.atan2(p.x, p.z); p.pitch = 0;
  p.alive = true; p.hp = 100; p.shield = 50; p.protUntil = now() + SPAWN_PROT; p.respawnAt = 0;
  broadcast(room, { t: 'spawn', id: p.id, p: [r2(p.x), 0, r2(p.z)], yaw: r3(p.yaw) });
}

function joinRoom(conn, m) {
  if (conn.player) return;
  const code = cleanRoom(m.room);
  let room = rooms.get(code);
  if (!room) { if (rooms.size >= MAX_ROOMS) return conn.send({ t: 'err', msg: '서버에 방이 너무 많아요. 잠시 후 다시 시도해 주세요.' }); room = makeRoom(code); }
  if (room.players.size >= MAX_PLAYERS) return conn.send({ t: 'err', msg: '방이 꽉 찼어요 (최대 ' + MAX_PLAYERS + '명).' });
  const used = new Set([...room.players.values()].map(p => p.look)); let look = 0; while (used.has(look)) look++;
  const p = { id: nextId++, name: cleanName(m.name), look, conn, x: 0, y: 0, z: 0, yaw: 0, pitch: 0, cr: 0, w: 0, alive: false, hp: 100, shield: 50, kills: 0, deaths: 0, protUntil: 0, respawnAt: 0, tokens: 14, lastHitT: now() };
  conn.player = p; conn.room = room; room.players.set(p.id, p);
  conn.send({ t: 'welcome', id: p.id, room: code, goal: GOAL, timeLeft: Math.ceil(room.timeLeft), state: room.state, players: [...room.players.values()].map(pub), orbs: [...room.orbs.values()].map(o => ({ id: o.id, p: [r2(o.x), r2(o.z)] })) });
  broadcast(room, { t: 'join', player: pub(p) }, conn);
  log(`[${code}] ${p.name}(#${p.id}) 입장 · ${room.players.size}명`);
  if (room.state === 'playing') spawn(room, p); else p.respawnAt = 0;
}
function leaveRoom(conn) {
  const p = conn.player, room = conn.room; if (!p || !room) return;
  room.players.delete(p.id); conn.player = null;
  broadcast(room, { t: 'leave', id: p.id });
  log(`[${room.code}] ${p.name}(#${p.id}) 퇴장 · ${room.players.size}명`);
  if (!room.players.size) rooms.delete(room.code);
}

function damage(room, v, a, dmg, zone, w, head) {
  if (!v.alive || now() < v.protUntil) return;
  const before = v.hp + v.shield;
  let ab = 0; if (v.shield > 0) { ab = Math.min(v.shield, dmg * 0.66); v.shield -= ab; }
  v.hp -= dmg - ab;
  const dealt = Math.min(dmg, before);
  broadcast(room, { t: 'dmg', v: v.id, a: a.id, hp: Math.max(0, r2(v.hp)), sh: r2(v.shield), d: r2(dealt), zone, w });
  if (v.hp <= 0.5) {
    v.hp = 0; v.alive = false; v.deaths++; v.respawnAt = now() + RESPAWN;
    if (a !== v) a.kills++;
    broadcast(room, { t: 'kill', a: a.id, v: v.id, w, head: !!head, ak: a.kills, vd: v.deaths });
    if (room.orbs.size >= 14) { const first = room.orbs.keys().next().value; room.orbs.delete(first); broadcast(room, { t: 'orbgone', id: first }); }
    const o = { id: room.orbSeq++, x: v.x, z: v.z, t: now() };
    room.orbs.set(o.id, o); broadcast(room, { t: 'orb', id: o.id, p: [r2(o.x), r2(o.z)] });
    if (a.kills >= GOAL && room.state === 'playing') endMatch(room);
  }
}
function endMatch(room) {
  room.state = 'ended'; room.endedAt = now();
  const list = [...room.players.values()].sort((x, y) => y.kills - x.kills || x.deaths - y.deaths).map(p => ({ id: p.id, name: p.name, kills: p.kills, deaths: p.deaths }));
  broadcast(room, { t: 'match', state: 'ended', results: list, next: NEXT_MATCH, reason: room.timeLeft <= 0 ? 'time' : 'goal' });
  log(`[${room.code}] 경기 종료 · 1위 ${list[0] ? list[0].name + ' ' + list[0].kills + '킬' : '-'}`);
}
function startMatch(room) {
  room.state = 'playing'; room.timeLeft = MATCH_TIME;
  for (const id of room.orbs.keys()) broadcast(room, { t: 'orbgone', id }); room.orbs.clear();
  for (const p of room.players.values()) { p.kills = 0; p.deaths = 0; p.alive = false; }
  broadcast(room, { t: 'match', state: 'playing', timeLeft: MATCH_TIME, goal: GOAL });
  for (const p of room.players.values()) spawn(room, p);
}

function onMessage(conn, m) {
  if (m.t === 'hello') return joinRoom(conn, m);
  const p = conn.player, room = conn.room; if (!p || !room) return;
  switch (m.t) {
    case 'st': { // own movement (client authoritative, clamped to the map)
      if (!p.alive || !Array.isArray(m.p) || !Array.isArray(m.a)) return;
      const x = num(m.p[0], -HW, HW), y = num(m.p[1], 0, 4), z = num(m.p[2], -HH, HH), yaw = num(m.a[0], -1e4, 1e4), pitch = num(m.a[1], -1.6, 1.6);
      if (x === null || y === null || z === null || yaw === null || pitch === null) return;
      p.x = x; p.y = y; p.z = z; p.yaw = yaw; p.pitch = pitch;
      p.cr = num(m.c, 0, 1) || 0; p.w = [0, 1, 2].includes(m.w) ? m.w : 0;
      return;
    }
    case 'shot': { // relay for tracers / sound / muzzle flash
      if (!p.alive) return;
      const w = [0, 1, 2].includes(m.w) ? m.w : 0, out = { t: 'shot', id: p.id, w, alt: !!m.alt };
      if (Array.isArray(m.o) && m.o.length === 3 && m.o.every(v => num(v, -200, 200) !== null)) out.o = m.o.map(r2);
      if (Array.isArray(m.e)) out.e = m.e.slice(0, 3).filter(e => Array.isArray(e) && e.length === 3 && e.every(v => num(v, -500, 500) !== null)).map(e => e.map(r2));
      if (m.heavy) out.heavy = true;
      return broadcast(room, out, conn);
    }
    case 'hit': { // shooter-side hit detection, server applies the damage
      if (room.state !== 'playing' || !p.alive) return;
      const v = room.players.get(m.v); if (!v || v === p || !v.alive) return;
      const t = now(); p.tokens = Math.min(14, p.tokens + (t - p.lastHitT) * 12); p.lastHitT = t;
      if (p.tokens < 1) return; p.tokens -= 1;
      const dist = Math.hypot(v.x - p.x, v.z - p.z);
      if (m.w === 'knife') {
        if (dist > 3.6) return;
        const key = (m.heavy ? 'heavy' : 'light') + (m.back ? '_back' : '');
        return damage(room, v, p, KNIFE[key] || 50, 'body', 'knife', false);
      }
      const table = m.w === 'pistol' ? (m.alt ? DMG.pistol_alt : DMG.pistol) : m.w === 'rifle' ? DMG.rifle : null;
      if (!table || !['head', 'body', 'legs'].includes(m.zone) || dist > 230) return;
      return damage(room, v, p, table[m.zone], m.zone, m.w, m.zone === 'head');
    }
    case 'pick': {
      const o = room.orbs.get(m.id); if (!o || !p.alive || Math.hypot(o.x - p.x, o.z - p.z) > 2.2) return;
      room.orbs.delete(o.id); p.hp = 100; p.shield = 50;
      return broadcast(room, { t: 'orbgone', id: o.id, by: p.id, hp: 100, sh: 50 });
    }
    case 'ping': return conn.send({ t: 'pong', c: m.c });
  }
}

// ---------- game loop ----------
let lastTick = now();
setInterval(() => {
  const t = now(), dt = t - lastTick; lastTick = t;
  for (const room of rooms.values()) {
    if (room.state === 'playing') {
      room.timeLeft -= dt; if (room.timeLeft <= 0) { room.timeLeft = 0; endMatch(room); }
      for (const p of room.players.values()) if (!p.alive && p.respawnAt && t >= p.respawnAt) spawn(room, p);
      for (const o of room.orbs.values()) if (t - o.t > 30) { room.orbs.delete(o.id); broadcast(room, { t: 'orbgone', id: o.id }); }
    } else if (t - room.endedAt >= NEXT_MATCH) startMatch(room);
    const ps = []; for (const p of room.players.values()) if (p.alive) ps.push([p.id, r2(p.x), r2(p.y), r2(p.z), r3(p.yaw), r3(p.pitch), r2(p.cr), p.w]);
    broadcast(room, { t: 'snap', tl: Math.ceil(room.timeLeft), ps });
  }
}, TICK);
// flood budget refill + dead connection sweep
setInterval(() => {
  const t = Date.now();
  for (const room of rooms.values()) for (const p of room.players.values()) { p.conn.msgBudget = 120; if (t - p.conn.alive > 30000) p.conn.close(); }
}, 1000);
setInterval(() => { for (const room of rooms.values()) for (const p of room.players.values()) p.conn.frame(9, Buffer.alloc(0)); }, 10000);

// ---------- http: serve the game + websocket upgrade ----------
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8' };
const FILES = { '/': 'index.html', '/index.html': 'index.html', '/three.min.js': 'three.min.js' };
const server = http.createServer((req, res) => {
  const url = (req.url || '/').split('?')[0];
  if (url === '/status') { res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify({ ok: true, rooms: [...rooms.values()].map(r => ({ code: r.code, players: r.players.size, state: r.state })) })); }
  const f = FILES[url];
  if (req.method !== 'GET' || !f) { res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }); return res.end('not found'); }
  fs.readFile(path.join(PUBLIC, f), (err, data) => {
    if (err) { res.writeHead(500); return res.end('missing ' + f); }
    res.writeHead(200, { 'content-type': TYPES[path.extname(f)] || 'application/octet-stream', 'cache-control': 'no-cache' }); res.end(data);
  });
});
server.on('upgrade', (req, sock) => {
  const key = req.headers['sec-websocket-key'];
  if (String(req.headers.upgrade || '').toLowerCase() !== 'websocket' || !key) return sock.destroy();
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  new Conn(sock);
});
function log(s) { console.log(new Date().toTimeString().slice(0, 8), s); }
server.listen(PORT, () => {
  log(`SUNDOWN 서버 실행 중 · 포트 ${PORT}`);
  log(`이 컴퓨터에서: http://localhost:${PORT}/   친구들은: http://<공인IP 또는 도메인>:${PORT}/`);
});
