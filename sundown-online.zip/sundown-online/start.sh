#!/bin/sh
cd "$(dirname "$0")"
command -v node >/dev/null 2>&1 || { echo "Node.js가 필요해요: https://nodejs.org"; exit 1; }
exec node server.js
